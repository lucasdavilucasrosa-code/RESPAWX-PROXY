package com.respawx.proxy

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = android.graphics.Color.rgb(5, 12, 27)
        window.navigationBarColor = android.graphics.Color.rgb(5, 12, 27)
        setContentView(RespawView())
    }
}

private data class Dummy(
    val x: Float, val y: Float, val w: Float, val h: Float,
    val label: String, val hp: Float, val distance: Int
)

private class RespawView : View() {
    private val bg = android.graphics.Color.rgb(5, 12, 27)
    private val panel = android.graphics.Color.rgb(12, 24, 48)
    private val blue = android.graphics.Color.rgb(42, 157, 244)
    private val cyan = android.graphics.Color.rgb(73, 220, 255)
    private val white = android.graphics.Color.rgb(230, 242, 255)
    private val muted = android.graphics.Color.rgb(133, 158, 190)
    private val green = android.graphics.Color.rgb(62, 220, 160)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var espBox = true
    private var espLine = true
    private var aimDemo = false
    private var running = true
    private var showLab = true
    private var lastW = 1f
    private var lastH = 1f
    private var pulse = 0f
    private var selected = -1
    private var frameTime = System.currentTimeMillis()

    private val targets = listOf(
        Dummy(.22f, .44f, .105f, .25f, "BOT-01", .82f, 18),
        Dummy(.52f, .37f, .11f, .28f, "BOT-02", .64f, 26),
        Dummy(.78f, .49f, .10f, .24f, "BOT-03", .93f, 34)
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        lastW = w; lastH = h
        canvas.drawColor(bg)
        drawHeader(canvas, w)
        drawPreview(canvas, w, h)
        drawControls(canvas, w, h)
        drawFooter(canvas, w, h)
        pulse = (pulse + .045f) % (2f * PI.toFloat())
        postInvalidateDelayed(33)
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false) {
        p.color = color; p.textSize = size
        p.typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
        p.style = Paint.Style.FILL
        c.drawText(s, x, y, p)
    }

    private fun rounded(c: Canvas, r: RectF, radius: Float, color: Int, stroke: Boolean = false) {
        p.color = color; p.style = if (stroke) Paint.Style.STROKE else Paint.Style.FILL
        p.strokeWidth = if (stroke) 2f else 1f
        c.drawRoundRect(r, radius, radius, p)
        p.style = Paint.Style.FILL
    }

    private fun drawHeader(c: Canvas, w: Float) {
        rounded(c, RectF(16f, 18f, w-16f, 100f), 18f, panel)
        p.shader = null
        text(c, "RESPAW X", 32f, 53f, 23f, white, true)
        text(c, "PROXY  /  TRAINING SANDBOX", 33f, 76f, 10f, cyan, true)
        rounded(c, RectF(w-112f, 34f, w-31f, 62f), 14f,
            if (running) android.graphics.Color.rgb(10, 67, 67) else android.graphics.Color.rgb(65, 39, 49))
        text(c, if (running) "● ACTIVE" else "○ PAUSED", w-103f, 53f, 10f,
            if (running) green else android.graphics.Color.LTGRAY, true)
    }

    private fun drawPreview(c: Canvas, w: Float, h: Float) {
        val top = 116f
        val bottom = min(h * .59f, 510f)
        rounded(c, RectF(16f, top, w-16f, bottom), 18f, panel)
        text(c, "LIVE SIMULATION", 30f, top+27f, 11f, cyan, true)
        text(c, "FICTIONAL TARGETS  •  OFFLINE", 30f, top+45f, 9f, muted)
        val cx = w/2f
        val cy = top + (bottom-top)*.56f
        // grid
        p.color = android.graphics.Color.rgb(22, 46, 76); p.strokeWidth = 1f
        for (i in 1..3) {
            c.drawLine(25f, top+60f+i*45f, w-25f, top+60f+i*45f, p)
        }
        c.drawLine(cx, top+55f, cx, bottom-15f, p)
        // reticle
        val retX = if (aimDemo && running) cx + sin(pulse)*24f else cx
        val retY = cy
        p.color = cyan; p.style = Paint.Style.STROKE; p.strokeWidth = 1.7f
        c.drawCircle(retX, retY, 15f, p)
        c.drawLine(retX-23f, retY, retX-7f, retY, p)
        c.drawLine(retX+7f, retY, retX+23f, retY, p)
        c.drawLine(retX, retY-23f, retX, retY-7f, p)
        c.drawLine(retX, retY+7f, retX, retY+23f, p)
        p.style = Paint.Style.FILL

        targets.forEachIndexed { i, t ->
            val tx = t.x*w
            val ty = top + (bottom-top)*.20f + t.y*(bottom-top)*.60f
            val bw = t.w*w
            val bh = t.h*(bottom-top)*.75f
            val rect = RectF(tx-bw/2, ty-bh/2, tx+bw/2, ty+bh/2)
            if (espLine) {
                p.color = blue; p.strokeWidth = 1.4f
                c.drawLine(cx, bottom-18f, tx, rect.bottom, p)
            }
            if (espBox) {
                p.color = if (selected == i && aimDemo) cyan else blue
                p.style = Paint.Style.STROKE; p.strokeWidth = 2f
                c.drawRoundRect(rect, 5f, 5f, p)
                p.style = Paint.Style.FILL
                text(c, t.label, rect.left, rect.top-9f, 9f, cyan, true)
                // health bar
                rounded(c, RectF(rect.left, rect.bottom+5f, rect.right, rect.bottom+9f), 2f,
                    android.graphics.Color.rgb(37, 54, 76))
                rounded(c, RectF(rect.left, rect.bottom+5f, rect.left+bw*t.hp, rect.bottom+9f), 2f, green)
                text(c, "${t.distance}m", rect.right+4f, rect.top+12f, 8f, muted)
            }
        }
        if (aimDemo && running) {
            selected = 1
            text(c, "AIM ASSIST DEMO: BOT-02", 30f, bottom-18f, 9f, green, true)
        } else {
            selected = -1
            text(c, "TARGETS: 03   |   MODE: LOCAL", 30f, bottom-18f, 9f, muted, true)
        }
    }

    private fun drawControls(c: Canvas, w: Float, h: Float) {
        val top = min(h*.59f, 510f) + 14f
        text(c, "SANDBOX CONTROLS", 22f, top+13f, 11f, white, true)
        val gap = 10f
        val cardW = (w-42f)/2f
        val cardH = 66f
        val items = listOf(
            Triple("ESP BOX", "Bounding boxes", espBox),
            Triple("ESP LINE", "Target guide lines", espLine),
            Triple("AIM ASSIST", "Reticle demo only", aimDemo),
            Triple("SIMULATION", "Run dummy targets", running)
        )
        items.forEachIndexed { i, item ->
            val col = i%2
            val row = i/2
            val x = 16f + col*(cardW+10f)
            val y = top+24f+row*(cardH+10f)
            rounded(c, RectF(x,y,x+cardW,y+cardH), 14f, panel)
            text(c, item.first, x+12f, y+25f, 11f, white, true)
            text(c, item.second, x+12f, y+43f, 8f, muted)
            rounded(c, RectF(x+cardW-53f,y+18f,x+cardW-12f,y+43f), 13f,
                if (item.third) android.graphics.Color.rgb(8,77,104) else android.graphics.Color.rgb(39,52,72))
            text(c, if(item.third) "ON" else "OFF", x+cardW-45f, y+35f, 9f,
                if(item.third) cyan else muted, true)
        }
        val btnY = top+24f+2*(cardH+10f)+4f
        rounded(c, RectF(16f,btnY,w-16f,btnY+48f), 14f, blue)
        text(c, if(running) "PAUSAR SIMULAÇÃO" else "INICIAR SIMULAÇÃO", 0f, 0f, 1f, white)
        p.textSize=12f; p.typeface=Typeface.DEFAULT_BOLD
        val label = if(running) "PAUSAR SIMULAÇÃO" else "INICIAR SIMULAÇÃO"
        val tw=p.measureText(label)
        text(c,label,(w-tw)/2f,btnY+30f,12f,android.graphics.Color.WHITE,true)
    }

    private fun drawFooter(c: Canvas, w: Float, h: Float) {
        val y = h-28f
        text(c, "RESPAW X  •  DEMO OFFLINE  •  v1.0", 22f, y, 9f, muted)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val x=event.x; val y=event.y
            val top = min(lastH*.59f,510f)+14f
            val cardW=(lastW-42f)/2f
            val cardH=66f
            val baseY=top+24f
            for(i in 0..3) {
                val col=i%2; val row=i/2
                val left=16f+col*(cardW+10f)
                val yy=baseY+row*(cardH+10f)
                if(x in left..(left+cardW) && y in yy..(yy+cardH)) {
                    when(i) {
                        0 -> espBox=!espBox
                        1 -> espLine=!espLine
                        2 -> aimDemo=!aimDemo
                        3 -> running=!running
                    }
                    invalidate(); return true
                }
            }
            val btnY=top+24f+2*(cardH+10f)+4f
            if(y in btnY..(btnY+48f)) { running=!running; invalidate(); return true }
        }
        return true
    }
}
