# RESPAW X PROXY MOBILE

Aplicativo Android nativo de demonstração visual, com alvos fictícios gerados localmente.

## Recursos
- Painel mobile azul escuro.
- ESP Box e ESP Line sobre bonecos fictícios desenhados no próprio app.
- Aim Assist demonstrativo: anima somente o retículo em direção a um alvo fictício.
- Controles ON/OFF e pausar/retomar simulação.
- Não lê a memória de jogos, não injeta código, não captura tela de outros apps e não interage com Free Fire.

## Requisitos
- Android Studio (versão compatível com Android Gradle Plugin 8.7.3)
- JDK 17
- Android SDK Platform 35

## Compilar APK debug
Abra a pasta `RESPAW_X_PROXY_MOBILE` no Android Studio e aguarde a sincronização do Gradle. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

APK gerado em:

`app/build/outputs/apk/debug/app-debug.apk`

## Instalar
Transfira o APK para um aparelho Android e instale-o. Para instalação manual, talvez seja necessário permitir a instalação de apps dessa origem nas configurações do Android.
